#include "EMS.h"

// Initialize HR instance to nullptr
HR* HR::instance = nullptr;

   HR:: HR(string name, int employeeId): Admin(name, employeeId) {}

     HR* HR::getInstance() {
        if (!instance) {
            instance = new HR("HR", 100); // default HR object
        }
        return instance;
    }
    void HR::display() {
        cout << "HR Name: " << name << " HR ID: " << employeeId << endl;
    }

