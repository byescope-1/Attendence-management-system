#include "EMS.h"

    Admin::Admin(string name, int employeeId): Employee(name, employeeId) {}
    string Admin::getType() {
        return "Admin";
    }

