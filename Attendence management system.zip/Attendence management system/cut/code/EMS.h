#ifndef __EMS_H__
#define __EMS_H__
#include <iostream>
#include <string>
#include <map>
#include <chrono>
#include <algorithm>
#include <memory>
#include <fstream>

using namespace std;
// Employee base class
class Employee {
protected:
    string name;
    int employeeId;
public:
    Employee(string name, int employeeId);
    virtual ~Employee();
    virtual string getType() = 0; // abstract function
    string getName() const;
};
// Admin class (subclass of Employee)
class Admin: public Employee {
public:
    Admin(string name, int employeeId);
    virtual string getType() override;
};
// Manager class (subclass of Employee)
class Manager: public Employee {
public:
    Manager(string name, int employeeId);
    virtual string getType() override;
};
// Singleton HR class (subclass of Admin)
class HR: public Admin {
private:
    static HR* instance;
    HR(string name, int employeeId);
public:
    static HR* getInstance();
    void display();
};


// LoginTime struct to store login and logout time
struct LoginTime {
    time_t login = -1;
    time_t logout = -1;
};

void EmployeeLogin(map<int, pair<unique_ptr<Employee>, LoginTime>>& employees);
void EmployeeDisplay(map<int, pair<unique_ptr<Employee>, LoginTime>>& employees);
void EmployeeLogout(map<int, pair<unique_ptr<Employee>, LoginTime>>& employees);
void WorkingHours(map<int, pair<unique_ptr<Employee>, LoginTime>>& employees);

#endif