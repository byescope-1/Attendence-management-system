#include "EMS.h"

    Employee::Employee(string name, int employeeId): name(name), employeeId(employeeId) {}
    Employee:: ~Employee() {}
    string Employee::getName() const { return name; }