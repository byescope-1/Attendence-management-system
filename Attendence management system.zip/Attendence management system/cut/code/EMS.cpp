#include "EMS.h"


// Function to capture employee details and login time
void EmployeeLogin(map<int, pair<unique_ptr<Employee>, LoginTime>>& employees) {
    int employeeId;
    string name;
    string type;
    cout << "Enter employee ID: ";
    cin >> employeeId;
    
    // Check if employee ID already exists in map
    if (employees.count(employeeId)) {
        cout << "Employee with ID " << employeeId << " already exists." << endl;
        return;
    }

    cout << "Enter employee name: ";
    cin >> name;
    cout << "Enter employee type (Admin/Manager): ";
    cin >> type;

    unique_ptr<Employee> employee = nullptr;
    if (type == "Admin") {
        employee = make_unique<Admin>(name, employeeId);
    }
    else if (type == "Manager") {
        employee = make_unique<Manager>(name, employeeId);
    }
    else {
        cout << "Invalid employee type!" << endl;
        return;
    }

    LoginTime loginTime = {time(nullptr), -1};
    employees[employeeId] = make_pair(move(employee), loginTime);
    ofstream file("employees.txt",ios::app);
    if(file.is_open()){
      file << "Employee Id: "<< employeeId << "\t" << "Employee Name: " << name << "\t" << "Employee Type: " << type << "\t" << "Login Time: " << ctime(&loginTime.login)<<endl;
      file.close();
      cout << "Employee login time recorded successfully!" << endl;
      }else{
      cout<<"Unable to open file!"<<endl;
    }
}


// Predicate function to order by employee id
static bool orderByEmployeeId(const pair<int, pair<Employee*, LoginTime>>& p1, const pair<int, pair<Employee*, LoginTime>>& p2) {
    return p1.first < p2.first;
}
// Predicate function to order by login time
static bool orderByLoginTime(const pair<int, pair<Employee*, LoginTime>>& p1, const pair<int, pair<Employee*, LoginTime>>& p2) {
    return p1.second.second.login < p2.second.second.login;
}

// Function to display employee list sorted by employee ID and login time
void EmployeeDisplay(map<int, pair<unique_ptr<Employee>, LoginTime>>& employees) {
    // Create a vector of employee id and employee-login pairs
    vector<pair<int, pair<Employee*, LoginTime>>> employeeList;
    for (auto& emp : employees) {
        employeeList.push_back(make_pair(emp.first, make_pair(emp.second.first.get(), emp.second.second)));
    }

    // Sort the employee list by employee ID
    sort(employeeList.begin(), employeeList.end(), orderByEmployeeId);

    // Sort the employee list by login time for each employee with the same ID
    int i = 0;
    while (i < employeeList.size()) {
        int j = i;
        while (j < employeeList.size() && employeeList[j].first == employeeList[i].first) {
            j++;
        }
        sort(employeeList.begin() + i, employeeList.begin() + j, orderByLoginTime);
        i = j;
    }

    // Display the sorted employee list
    cout << "Employee List:" << endl;
    for (auto& emp : employeeList) {
        cout << "Employee ID: " << emp.first << ", Employee Name: " << emp.second.first->getName()
             << ", Employee Type: " << emp.second.first->getType() << ", Login Time: " << ctime(&emp.second.second.login);
    }
}
void EmployeeLogout(map<int, pair<unique_ptr<Employee>, LoginTime>>& employees) {
    int employeeId;
    cout << "Enter employee ID: ";
    cin >> employeeId;

    // Check if employee exists
    auto it = employees.find(employeeId);
    if (it == employees.end()) {
        cout << "Employee not found!" << endl;
        return;
    }

    // Check if employee has already logged out
    LoginTime& loginTime = it->second.second;
    if (loginTime.logout != -1) {
        cout << "Employee has already logged out at " << ctime(&loginTime.logout) << endl;
        return;
    }

    // Update logout time
    loginTime.logout = time(nullptr);
     cout << "Employee " << it->second.first->getName() << " has logged out at " << ctime(&loginTime.logout) << endl;
   ofstream file("employees1.txt", ios::app);
    if (file.is_open()) {
        file << "Employee Id: " << employeeId << "\t" << "Logout Time: " << ctime(&loginTime.logout) << endl;
        file.close();
        cout << "Employee logout time recorded successfully!" << endl;
    } else {
        cout << "Unable to open file!" << endl;
    }
    

}
void WorkingHours(map<int, pair<unique_ptr<Employee>, LoginTime>>& employees) {
    ofstream file("employees2.txt",ios::app);
    if(file.is_open()){
        // Iterate through the employee list
        for (auto& emp : employees) {
            // Check if employee has logged in and out
            LoginTime& loginTime = emp.second.second;
            if (loginTime.login != -1 && loginTime.logout != -1) {
                // Calculate working hours
                double workingHours = difftime(loginTime.logout, loginTime.login) / 3600.0; // convert from seconds to hours
                file << "Employee ID: " << emp.first << "\tEmployee Name: " << emp.second.first->getName() << "\tWorking Hours: " << workingHours << endl;
                cout << "Employee " << emp.second.first->getName() << " worked " << workingHours << " hours." << endl;
            }
        }
        file.close();
        cout << "Working hours recorded successfully!" << endl;
    } else {
        cout << "Unable to open file!" << endl;
    }
}