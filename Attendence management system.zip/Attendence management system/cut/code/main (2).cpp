#include "EMS.h"
int main() {
map<int, pair<unique_ptr<Employee>, LoginTime>> employees;
// Display HR information
HR::getInstance()->display();

// Menu options
int choice;
do {
    cout << "Menu:" << endl;
    cout <<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    cout << "1. Employee Login" << endl;
    cout << "2. Employee Logout" << endl;
    cout << "3. Display Employee List" << endl;
    cout << "4. Display Working Hours" << endl;
    cout << "5. Exit" << endl;
    cout <<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
        case 1:
            EmployeeLogin(employees);
            break;
        case 2:
            EmployeeLogout(employees);
            break;
        case 3:
            EmployeeDisplay(employees);
            break;
        case 4:
            WorkingHours(employees);
            break;
        case 5:
            cout << "Exiting program..." << endl;
            break;
        default:
            cout << "Invalid choice!" << endl;
    }
} while (choice != 5);

return 0;

}