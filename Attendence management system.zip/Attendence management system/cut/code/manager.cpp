#include "EMS.h"

   Manager:: Manager(string name, int employeeId): Employee(name, employeeId) {}
   string Manager:: getType() {
        return "Manager";
    }
